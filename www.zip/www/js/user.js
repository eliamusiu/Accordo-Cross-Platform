class User {
    set uid(uid) {
        this._uid = uid
    }

    get uid() {
        return this._uid
    }

    set pversion(pversion) {
        this._pversion = pversion
    }

    get pversion() {
        return this._pversion
    }

    set picture(picture) {
        this._picture = picture
    }

    get picture() {
        return this._picture
    }

    set name(name) {
        this._name = name
    }

    get name() {
        return this._name
    }
}